/**
* Random Quote Web Service
*
* This is a web service that provides random quotes and allows users to like and dislike quotes.
* The project is built using Java 17, Spring Boot, and Gradle.
*
* It provides the following API endpoints:
* - GET /api/quotes/random: Get a random quote.
* - POST /api/quotes/like/{quoteId}: Like a quote by its ID.
* - POST /api/quotes/dislike/{quoteId}: Dislike a quote by its ID.
* - GET /api/quotes/highly-rated: Get highly rated quotes with a minimum rating.
* - GET /api/quotes/comparable: Find quotes comparable to the currently shown quote based on tags or authors.
*
* The service fetches random quotes from an external API and stores them in an in-memory H2 database.
* Users can like or dislike quotes, and highly rated quotes are prioritized for new users.
* The service also provides a GraphQL API alongside the existing REST API for more flexible querying.
*
* Technologies used:
* - Java 17
* - Spring Boot
* - Gradle
* - H2 Database
* - GraphQL (optional, for flexible querying)
    Postman Testing:
    POST : http://localhost:8080/graphql
    body: {
    "query": "{ getRandomQuote { _id content author tags authorSlug length dateAdded dateModified rating } }"
    },{ "query": "{ getHighlyRatedQuotes(minRating: 3) { _id content author rating } }"}, {"query": "{ findComparableQuotes(quoteId: 1) { _id content author rating } }"}
*
* Project Structure:
* - com.api.randomquote.config: Configuration classes for the application.
* - com.example.randomquote.controller: REST API controllers for handling HTTP requests.
* - com.api.randomquote.dto: Data Transfer Objects used for API response and request payloads.
* - com.api.randomquote.entity: JPA entities representing database tables.
* - com.api.randomquote.graphql: GraphQL schema and resolvers (optional).
* - com.api.randomquote.repository: JPA repositories for database operations.
* - com.api.randomquote.service: Service classes for business logic and external API integration.
*
* Note: This is a simplified description for documentation purposes. Actual implementation may include more features.
  */