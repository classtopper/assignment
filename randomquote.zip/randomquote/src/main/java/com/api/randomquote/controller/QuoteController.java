package com.api.randomquote.controller;

import com.api.randomquote.dto.QuoteDto;
import com.api.randomquote.service.QuoteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/quotes")
public class QuoteController {
    private final QuoteService quoteService;

    @Autowired
    public QuoteController(QuoteService quoteService) {
        this.quoteService = quoteService;
    }

    @GetMapping("/random")
    public ResponseEntity<QuoteDto> getRandomQuote() {
        QuoteDto randomQuote = quoteService.getRandomQuote();
        return ResponseEntity.ok(randomQuote);
    }
    @PostMapping("/like/{quoteId}")
    public ResponseEntity<String> likeQuote(@PathVariable Long quoteId) {
        quoteService.likeQuote(quoteId);
        return ResponseEntity.ok("Quote with ID " + quoteId + " liked successfully.");
    }

    @PostMapping("/dislike/{quoteId}")
    public ResponseEntity<String> dislikeQuote(@PathVariable Long quoteId) {
        quoteService.dislikeQuote(quoteId);
        return ResponseEntity.ok("Quote with ID " + quoteId + " disliked successfully.");
    }
    @GetMapping("/highly-rated")
    public ResponseEntity<List<QuoteDto>> getHighlyRatedQuotes(@RequestParam int minRating) {
        List<QuoteDto> highlyRatedQuotes = quoteService.getHighlyRatedQuotes(minRating);
        return ResponseEntity.ok(highlyRatedQuotes);
    }
    @GetMapping("/comparable")
    public ResponseEntity<List<QuoteDto>> findComparableQuotes(@RequestParam Long quoteId) {
        List<QuoteDto> comparableQuotes = quoteService.findComparableQuotes(quoteId);
        return ResponseEntity.ok(comparableQuotes);
    }
}
