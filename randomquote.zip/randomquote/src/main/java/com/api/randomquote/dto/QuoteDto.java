package com.api.randomquote.dto;

import java.util.List;

public class QuoteDto {
    private String _id;
    private String content;
    private String author;
    private List<String> tags;
    private String authorSlug;
    private int length;
    private String dateAdded;
    private String dateModified;
    private int rating;

    // Getters and Setters

    public String get_id() {
        return _id;
    }

    public String getContent() {
        return content;
    }

    public String getAuthor() {
        return author;
    }

    public List<String> getTags() {
        return tags;
    }

    public String getAuthorSlug() {
        return authorSlug;
    }

    public int getLength() {
        return length;
    }

    public String getDateAdded() {
        return dateAdded;
    }

    public String getDateModified() {
        return dateModified;
    }

    public int getRating() {
        return rating;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setTags(List<String> tags) {
        this.tags = tags;
    }

    public void setAuthorSlug(String authorSlug) {
        this.authorSlug = authorSlug;
    }

    public void setLength(int length) {
        this.length = length;
    }

    public void setDateAdded(String dateAdded) {
        this.dateAdded = dateAdded;
    }

    public void setDateModified(String dateModified) {
        this.dateModified = dateModified;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }
}