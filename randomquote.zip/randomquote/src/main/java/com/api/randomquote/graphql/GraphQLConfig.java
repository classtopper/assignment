package com.api.randomquote.graphql;

import graphql.GraphQL;
import graphql.schema.GraphQLSchema;
import graphql.schema.idl.RuntimeWiring;
import graphql.schema.idl.SchemaGenerator;
import graphql.schema.idl.SchemaParser;
import graphql.schema.idl.TypeDefinitionRegistry;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

@Configuration
public class GraphQLConfig implements WebMvcConfigurer {
    private final GraphQLDataFetchers graphQLDataFetchers;

    public GraphQLConfig(GraphQLDataFetchers graphQLDataFetchers) {
        this.graphQLDataFetchers = graphQLDataFetchers;
    }

    @Bean
    public GraphQL graphQL() throws IOException {
        Resource schemaResource = new ClassPathResource("randomquote.graphqls");
        String schemaString = new String(schemaResource.getInputStream().readAllBytes(), StandardCharsets.UTF_8);

        GraphQLSchema schema = buildSchema(schemaString);
        return GraphQL.newGraphQL(schema).build();
    }

    private GraphQLSchema buildSchema(String schemaString) {
        SchemaParser schemaParser = new SchemaParser();
        TypeDefinitionRegistry typeDefinitionRegistry = schemaParser.parse(schemaString);
        SchemaGenerator schemaGenerator = new SchemaGenerator();
        return schemaGenerator.makeExecutableSchema(typeDefinitionRegistry, buildWiring());
    }

    private RuntimeWiring buildWiring() {
        return RuntimeWiring.newRuntimeWiring()
                .type("Query", typeWiring -> typeWiring
                        .dataFetcher("getRandomQuote", graphQLDataFetchers.getRandomQuote())
                        .dataFetcher("getQuoteById", graphQLDataFetchers.getQuoteById())
                        .dataFetcher("getHighlyRatedQuotes", graphQLDataFetchers.getHighlyRatedQuotes())
                        .dataFetcher("findComparableQuotes", graphQLDataFetchers.findComparableQuotes()))
                .build();
    }
}
