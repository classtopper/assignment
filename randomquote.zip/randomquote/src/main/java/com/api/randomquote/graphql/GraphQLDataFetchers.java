package com.api.randomquote.graphql;

import com.api.randomquote.dto.QuoteDto;
import com.api.randomquote.service.QuoteService;
import graphql.schema.DataFetcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class GraphQLDataFetchers {
    @Autowired
    private QuoteService quoteService;

    public DataFetcher<QuoteDto> getRandomQuote() {
        return dataFetchingEnvironment -> quoteService.getRandomQuote();
    }

    public DataFetcher<QuoteDto> getQuoteById() {
        return dataFetchingEnvironment -> {
            Long quoteId = dataFetchingEnvironment.getArgument("quoteId");
            return quoteService.getQuoteById(quoteId);
        };
    }

    public DataFetcher<List<QuoteDto>> getHighlyRatedQuotes() {
        return dataFetchingEnvironment -> {
            int minRating = dataFetchingEnvironment.getArgument("minRating");
            return quoteService.getHighlyRatedQuotes(minRating);
        };
    }

    public DataFetcher<List<QuoteDto>> findComparableQuotes() {
        return dataFetchingEnvironment -> {
            Long quoteId = dataFetchingEnvironment.getArgument("quoteId");
            return quoteService.findComparableQuotes(quoteId);
        };
    }
}
