package com.api.randomquote.repository;

import com.api.randomquote.entity.Quote;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface QuoteRepository extends JpaRepository<Quote, Long> {
    List<Quote> findAllByRatingGreaterThanEqual(int minRating);
    List<Quote> findByTagsInOrAuthorIgnoreCase(List<String> tags, String author);
}