package com.api.randomquote.service;

import com.api.randomquote.dto.QuoteDto;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class QuoteApiService {
    private static final String QUOTE_API_URL = "https://api.quotable.io/random";

    private final RestTemplate restTemplate;

    public QuoteApiService() {
        this.restTemplate = new RestTemplate();
    }

    public QuoteDto fetchRandomQuote() {
        ResponseEntity<QuoteDto> responseEntity = restTemplate.getForEntity(QUOTE_API_URL, QuoteDto.class);
        return responseEntity.getBody();
    }
}
