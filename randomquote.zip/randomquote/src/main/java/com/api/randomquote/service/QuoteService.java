package com.api.randomquote.service;

import com.api.randomquote.dto.QuoteDto;

import java.util.List;

public interface QuoteService {
    QuoteDto getRandomQuote();
    QuoteDto getQuoteById(Long quoteId);
    void likeQuote(Long quoteId);
    void dislikeQuote(Long quoteId);
    List<QuoteDto> getHighlyRatedQuotes(int minRating);
    List<QuoteDto> findComparableQuotes(Long quoteId);
}