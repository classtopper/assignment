package com.api.randomquote.service;

import com.api.randomquote.dto.QuoteDto;
import com.api.randomquote.entity.Quote;
import com.api.randomquote.repository.QuoteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

@Service
public class QuoteServiceImpl implements QuoteService {
    @Autowired
    private QuoteRepository quoteRepository;
    @Autowired
    private QuoteApiService quoteApiService;
    private static final int MIN_RATING_THRESHOLD = 4;

    @Override
    public QuoteDto getRandomQuote() {
        List<QuoteDto> highlyRatedQuotes = getHighlyRatedQuotes(MIN_RATING_THRESHOLD);
        if (!highlyRatedQuotes.isEmpty()) {
            int randomIndex = new Random().nextInt(highlyRatedQuotes.size());
            return highlyRatedQuotes.get(randomIndex);
        } else {
            // Fetch a random quote from the remote API if there are no highly rated quotes
            QuoteDto randomQuote = quoteApiService.fetchRandomQuote();
            // Save the quote to the database
            Quote savedQuote = saveQuoteToDatabase(randomQuote);
            // Map the saved quote to DTO and return
            return mapQuoteToDto(savedQuote);
        }
    }

    @Override
    public QuoteDto getQuoteById(Long quoteId) {
        // Implement logic to retrieve a quote by its ID from the database
        Quote quote = quoteRepository.findById(quoteId).orElse(null);
        return quote != null ? mapQuoteToDto(quote) : null;
    }

    @Override
    public void likeQuote(Long quoteId) {
        Quote quote = quoteRepository.findById(quoteId).orElse(null);
        if (quote != null) {
            // Increment the like count or handle the like logic here
            quote.setRating(quote.getRating() + 1);
            quoteRepository.save(quote);
        }
    }
    @Override
    public void dislikeQuote(Long quoteId) {
        // Fetch the quote from the database by ID
        Quote quote = quoteRepository.findById(quoteId).orElse(null);

        if (quote != null) {
            // Decrease the rating or implement your logic for dislike
            int currentRating = quote.getRating();
            if (currentRating > 0) {
                quote.setRating(currentRating - 1);
                quoteRepository.save(quote);
            }
        }
    }

    @Override
    public List<QuoteDto> getHighlyRatedQuotes(int minRating) {
        List<Quote> highlyRatedQuotes = quoteRepository.findAllByRatingGreaterThanEqual(minRating);
        return highlyRatedQuotes.stream()
                .map(this::mapQuoteToDto)
                .collect(Collectors.toList());
    }

   @Override
    public List<QuoteDto> findComparableQuotes(Long quoteId) {
        QuoteDto shownQuote = getQuoteById(quoteId);
        if (shownQuote == null) {
            return Collections.emptyList();
        }

        // Get comparable quotes based on tags or authors
        List<Quote> comparableQuotes = quoteRepository.findByTagsInOrAuthorIgnoreCase(
                shownQuote.getTags(), shownQuote.getAuthor()
        );

        return comparableQuotes.stream()
                .map(this::mapQuoteToDto)
                .collect(Collectors.toList());
    }

    private Quote saveQuoteToDatabase(QuoteDto quoteDto) {
        // Map the QuoteDto to a Quote entity and save it to the database
        Quote quote = new Quote();
        quote.set_id(quoteDto.get_id());
        quote.setContent(quoteDto.getContent());
        quote.setAuthor(quoteDto.getAuthor());
        quote.setTags(quoteDto.getTags());
        quote.setAuthorSlug(quoteDto.getAuthorSlug());
        quote.setLength(quoteDto.getLength());
        quote.setDateAdded(quoteDto.getDateAdded());
        quote.setDateModified(quoteDto.getDateModified());
        quote.setRating(quoteDto.getRating());
        return quoteRepository.save(quote);
    }

    private QuoteDto mapQuoteToDto(Quote quote) {
        // Map the Quote entity to a QuoteDto
        QuoteDto quoteDto = new QuoteDto();
        quoteDto.set_id(quote.get_id());
        quoteDto.setContent(quote.getContent());
        quoteDto.setAuthor(quote.getAuthor());
        quoteDto.setTags(quote.getTags());
        quoteDto.setAuthorSlug(quote.getAuthorSlug());
        quoteDto.setLength(quote.getLength());
        quoteDto.setDateAdded(quote.getDateAdded());
        quoteDto.setDateModified(quote.getDateModified());
        quoteDto.setRating(quote.getRating());
        return quoteDto;
    }

}
