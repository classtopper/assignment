package com.api.randomquote;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RandomquoteApplicationTests {

	@Test
	void contextLoads() {
	}

}
