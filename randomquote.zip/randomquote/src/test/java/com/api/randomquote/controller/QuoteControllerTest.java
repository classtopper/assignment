package com.api.randomquote.controller;

import com.api.randomquote.dto.QuoteDto;
import com.api.randomquote.service.QuoteService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class QuoteControllerTest {

    @Mock
    private QuoteService quoteService;

    @InjectMocks
    private QuoteController quoteController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetRandomQuote() {
        // Mock data
        QuoteDto quoteDto = new QuoteDto();
        quoteDto.setContent("Test quote content");
        when(quoteService.getRandomQuote()).thenReturn(quoteDto);

        // Execute the method
        ResponseEntity<QuoteDto> response = quoteController.getRandomQuote();

        // Verify the result
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(quoteDto, response.getBody());

        // Verify that the service method was called once
        verify(quoteService, times(1)).getRandomQuote();
    }

    @Test
    void testLikeQuote() {
        // Mock data
        Long quoteId = 1L;

        // Execute the method
        ResponseEntity<String> response = quoteController.likeQuote(quoteId);

        // Verify the result
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Quote with ID " + quoteId + " liked successfully.", response.getBody());

        // Verify that the service method was called once
        verify(quoteService, times(1)).likeQuote(quoteId);
    }

    @Test
    void testDislikeQuote() {
        // Mock data
        Long quoteId = 2L;

        // Execute the method
        ResponseEntity<String> response = quoteController.dislikeQuote(quoteId);

        // Verify the result
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Quote with ID " + quoteId + " disliked successfully.", response.getBody());

        // Verify that the service method was called once
        verify(quoteService, times(1)).dislikeQuote(quoteId);
    }

    @Test
    void testGetHighlyRatedQuotes() {
        // Mock data
        int minRating = 4;
        List<QuoteDto> highlyRatedQuotes = Arrays.asList(
                new QuoteDto(),
                new QuoteDto()
        );
        highlyRatedQuotes.get(0).setContent("Quote 1");
        highlyRatedQuotes.get(0).setAuthor("Author 1");
        highlyRatedQuotes.get(0).setRating(5);
        highlyRatedQuotes.get(1).setContent("Quote 2");
        highlyRatedQuotes.get(1).setAuthor("Author 2");
        highlyRatedQuotes.get(1).setRating(4);

        when(quoteService.getHighlyRatedQuotes(minRating)).thenReturn(highlyRatedQuotes);

        // Execute the method
        ResponseEntity<List<QuoteDto>> response = quoteController.getHighlyRatedQuotes(minRating);

        // Verify the result
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(highlyRatedQuotes, response.getBody());

        // Verify that the service method was called once with the correct argument
        verify(quoteService, times(1)).getHighlyRatedQuotes(minRating);
    }
    @Test
    void testFindComparableQuotes() {
        // Mock data
        Long quoteId = 3L;
        List<QuoteDto> comparableQuotes = Arrays.asList(
                new QuoteDto(),
                new QuoteDto()
        );
        comparableQuotes.get(0).setContent("Quote 3");
        comparableQuotes.get(0).setAuthor("Author 3");
        comparableQuotes.get(0).setRating(3);
        comparableQuotes.get(1).setContent("Quote 4");
        comparableQuotes.get(1).setAuthor("Author 4");
        comparableQuotes.get(1).setRating(4);

        when(quoteService.findComparableQuotes(quoteId)).thenReturn(comparableQuotes);

        // Execute the method
        ResponseEntity<List<QuoteDto>> response = quoteController.findComparableQuotes(quoteId);

        // Verify the result
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(comparableQuotes, response.getBody());

        // Verify that the service method was called once with the correct argument
        verify(quoteService, times(1)).findComparableQuotes(quoteId);
    }
}